package sb.exception;

public class RestApiException extends Exception{
    public RestApiException(final String message) {
        super(message);
    }
}
