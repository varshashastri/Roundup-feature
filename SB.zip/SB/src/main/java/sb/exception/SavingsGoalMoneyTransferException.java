package sb.exception;

public class SavingsGoalMoneyTransferException extends Exception {
    public SavingsGoalMoneyTransferException(final String message) {
        super(message);
    }
}
