package sb.util;

import lombok.NonNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestHelper {

    @Value("${bearer.token}")
    String token;

    private final RestTemplate restTemplate = new RestTemplate();

    public <T> HttpEntity<T> getHttpEntityWithHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer " + token);
        HttpEntity<T> entity = new HttpEntity<>(httpHeaders);
        return entity;
    }

    public <T> HttpEntity<T> getHttpEntityWithRequestBodyAndHeaders(@NonNull T body) {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("Authorization", "Bearer " + token);
        HttpEntity<T> entity = new HttpEntity<>(body, httpHeaders);
        return entity;
    }

    public <T,S> ResponseEntity<S> performPut(@NonNull String url, T body, @NonNull Class<S> clazz) {
        HttpEntity<T> entity = getHttpEntityWithRequestBodyAndHeaders(body);//move to rest helper
        return restTemplate.exchange(url, HttpMethod.PUT, entity, clazz);
    }

    public <T,S> ResponseEntity<S> performGet(@NonNull final String url, @NonNull Class<S> clazz) {
        HttpEntity<T> entity = getHttpEntityWithHeaders();
        return restTemplate.exchange(url, HttpMethod.GET, entity, clazz);
    }
}
