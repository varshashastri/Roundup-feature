package sb.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"sb"})
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}



/*
things to do:
create savings goal if does not exist
get all accounts of user
get all transactions from all accounts
round up from all the transactions
add the round up to the savings goal.
 */